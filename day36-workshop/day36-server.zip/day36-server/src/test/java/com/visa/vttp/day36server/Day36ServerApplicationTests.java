package com.visa.vttp.day36server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day36ServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
